package jango;

public class Major {
    String title ;
    int pk ;
}
