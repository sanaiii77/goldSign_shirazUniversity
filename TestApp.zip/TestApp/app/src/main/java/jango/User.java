package jango;

public class User {
    int pk ;
    String username ;
    String password ;

    public User(int pk, String username, String password) {
        this.pk = pk;
        this.username = username;
        this.password = password;
    }

    public int getPk() {
        return pk;
    }

    public void setPk(int pk) {
        this.pk = pk;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
