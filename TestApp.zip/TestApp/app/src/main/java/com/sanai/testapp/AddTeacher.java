package com.sanai.testapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class AddTeacher extends Fragment {


    EditText tname,tfamilyname  ;
    String name, familyName,number ;
    Button saveTeacher ;
    int num = 0;
    Spinner attitudeOfTeacher;
    String[] interest = {"هوش مصنوعی","سخت افزار","نرم افزار","فناوری اطلاعات"} ;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add_teacher,container,false);

        //___________________________________________________________________________________
        tname =view.findViewById(R.id.teacherName);
        tfamilyname = view.findViewById(R.id.teacherFamilyName);
        attitudeOfTeacher = view.findViewById(R.id.attitudeOfTeacher);
        saveTeacher = view.findViewById(R.id.saveTeacher);
        save ();
        return  view;
    }

    public  void  save(){

        saveTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = tname.getText().toString();
                familyName = tfamilyname.getText().toString();

                if(number.matches("") || name.matches("") || familyName.matches("")){
                    Toast.makeText(getActivity(), "empty field doenst except", Toast.LENGTH_SHORT).show();

                }else {
                    num = Integer.parseInt(number);
                    // is he or she new teacher or not ?
                    dialog();
                }

            }
        });

    }
    public  void  goToDefaultFargment(){
        Fragment newFragment = new defaultFragment();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack
        transaction.replace(R.id.flcontent, newFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();

    }
    public  void  dialog (){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("افزودن استاد");
        builder.setMessage("آیا از صحت اطلاعات اطمینان دارین ؟");

        builder.setPositiveButton("بله", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Do nothing but close the dialog
                // add this student to backend
                goToDefaultFargment();
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("خیر", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

    public  void setSpinner (){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, interest);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        attitudeOfTeacher.setAdapter(adapter);
    }
}
