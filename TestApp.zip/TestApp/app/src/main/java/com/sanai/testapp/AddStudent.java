package com.sanai.testapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class AddStudent extends Fragment {

    EditText stdName ,stdFamilyName,stdNumber ,stdYearEnter , stdScore ;
    Button saveStd ;
    Spinner selectAttitude ;
    String name, familyName ,attitude;
    String number , yearEnter , score;
    int inumber , iyearEnter , iscore;
    String[] interest = {"هوش مصنوعی","سخت افزار","نرم افزار","فناوری اطلاعات"} ;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add_student,container,false);


        selectAttitude =  view.findViewById(R.id.spinner1);
        stdName = view.findViewById(R.id.studentName);
        stdFamilyName = view.findViewById(R.id.studentFamilyName);
        stdNumber = view.findViewById(R.id.stdNumber);
        stdYearEnter = view.findViewById(R.id.stdYearEnter);
        stdScore = view.findViewById(R.id.stdscore);
        saveStd = view.findViewById(R.id.saveStd);




        //__________________________________________________________________________\\
        attitudeSelection();
        setSpinner ();
        saveStud();

        return  view;
    }

    public  void saveStud (){
        saveStd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = stdName.getText().toString();
                familyName = stdFamilyName.getText().toString();
                number = (stdNumber.getText().toString());
                score = (stdScore.getText().toString());
                yearEnter =(stdYearEnter.getText().toString());

                if(name.matches("") || familyName.matches("") || number.matches("")
                || score.matches("") || yearEnter.matches("")){

                    Toast.makeText(getActivity(), "empty field does'nt except", Toast.LENGTH_SHORT).show();
                }
                else{
                    iscore =Integer.parseInt(score);
                    iyearEnter =Integer.parseInt(yearEnter);

                    //if its new go to save else alarm
                    dialog ();
                }


                }

                // check its new or not
                //if its new show dialog


        });

    }
    public  void  attitudeSelection (){
        selectAttitude.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
              attitude =( selectAttitude.getItemAtPosition(selectAttitude.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
    }
    public  void  goToDefaultFargment(){
        Fragment newFragment = new defaultFragment();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack
        transaction.replace(R.id.flcontent, newFragment);
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();


    }
    public  void setSpinner (){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, interest);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        selectAttitude.setAdapter(adapter);
    }
    public  void  dialog (){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("افزودن دانشجو");
        builder.setMessage("آیا از صحت اطلاعات اطمینان دارین ؟");

        builder.setPositiveButton("بله", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Do nothing but close the dialog
                // add this student to backend
                goToDefaultFargment();
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("خیر", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }
}
