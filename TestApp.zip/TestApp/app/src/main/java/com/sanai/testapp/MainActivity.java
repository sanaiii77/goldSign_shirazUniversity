package com.sanai.testapp;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import java.util.Calendar;


public class MainActivity extends AppCompatActivity {
    public DrawerLayout drawerLayout ;
    private ActionBarDrawerToggle toggle ;
    FragmentTransaction fragmentTransaction;
    Calendar cal = Calendar.getInstance();
    int [] today_persion = new int[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //**************************************************************************
        fragmentTransaction   = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.flcontent,new defaultFragment());
        fragmentTransaction.commit();
        //**************************************************************************

        drawerLayout =  findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(this,drawerLayout,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView nvDrawer = findViewById(R.id.nv);
        setupDrawerContent(nvDrawer);
        //****************************date*********************************


        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        today_persion = converter.gregorian_to_jalali(year,month,day);

        //**************************************************************************






    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (toggle.onOptionsItemSelected(item)){
            return  true;
        }
        return super.onOptionsItemSelected(item);
    }


    public  void  selectItemDrawer(MenuItem menuItem){ //action of clicking in menu item
        fragmentTransaction   = getSupportFragmentManager().beginTransaction();
        switch(menuItem.getItemId()) {
            case R.id.addStudent:
                fragmentTransaction.replace(R.id.flcontent,new AddStudent());
                break;
            case R.id.addTeacher:
                fragmentTransaction.replace(R.id.flcontent,new AddTeacher());
                break;
            case R.id.addNewTerm:
                fragmentTransaction.replace(R.id.flcontent,new AddNewTerm());
                break;
            case R.id.selectTerm :
                fragmentTransaction.replace(R.id.flcontent,new TermsList());
                break;
            case R.id.setting:
                fragmentTransaction.replace(R.id.flcontent,new ChangePassword());
                break;
            default:
                fragmentTransaction.replace(R.id.flcontent,new defaultFragment());

        }
        fragmentTransaction.commit();

        // Highlight the selected item has been done by NavigationView
        menuItem.setChecked(true);
        // Set action bar title
        setTitle("کارشناس بخش");
        // Close the navigation drawer
        drawerLayout.closeDrawers();

    }

    private void setupDrawerContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                selectItemDrawer(item);
                return false;
            }
        });
    }



}
