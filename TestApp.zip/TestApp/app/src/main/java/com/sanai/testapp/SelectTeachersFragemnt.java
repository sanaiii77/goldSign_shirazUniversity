package com.sanai.testapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;


public class SelectTeachersFragemnt extends Fragment {

    String[] teachersName = {"teacher1","techaer2"};
    Spinner choice1 , choice2 ,choice3 , choice4, choice5 ;
    Button save , cancel ;
    String[] choices = new String[5];

    FrameLayout notAvailable;
    LinearLayout isAvailable;
    TextView textView ;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_select_teachers_fragemnt,container,false);

        choice1 = view.findViewById(R.id.selectTeacher1);
        choice2 = view.findViewById(R.id.selectTeacher2);
        choice3 = view.findViewById(R.id.selectTeacher3);
        choice4 = view.findViewById(R.id.selectTeacher4);
        choice5 = view.findViewById(R.id.selectTeacher5);
        save = view.findViewById(R.id.saveChoiceOfTeacher);
        cancel = view.findViewById(R.id.cancelChoiceOfTeacher);
        notAvailable = view.findViewById(R.id.selectionIsNotAvailable);
        isAvailable =view.findViewById(R.id.teacherSelectionIsAvailable);
        textView = view.findViewById(R.id.textviewSelectionIsNotAvailable);

        /*_______________________________________________________________*/
        setSpinner();
        click();
        return  view;
    }

    public  void  setSpinner(){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, teachersName);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        choice1.setAdapter(adapter);
        //****************************************************************************************************
         adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, teachersName);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        choice2.setAdapter(adapter);
        //****************************************************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, teachersName);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        choice3.setAdapter(adapter);
        //****************************************************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, teachersName);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        choice4.setAdapter(adapter);
        //****************************************************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, teachersName);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        choice5.setAdapter(adapter);
    }
    public  void  click(){
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectOnSpinnerItem();
            }
        });


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToDefaultFragment();

            }
        });
    }
    public  void selectOnSpinnerItem(){
        choice1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                choices[0] = choice1.getItemAtPosition(choice1.getSelectedItemPosition()).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        //******************************************************************************************
        choice2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                choices[1] = choice2.getItemAtPosition(choice2.getSelectedItemPosition()).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        //******************************************************************************************
        choice3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                choices[2] = choice3.getItemAtPosition(choice3.getSelectedItemPosition()).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        //******************************************************************************************
        choice4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                choices[3] = choice4.getItemAtPosition(choice4.getSelectedItemPosition()).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        //******************************************************************************************
        choice5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                choices[4] = choice5.getItemAtPosition(choice5.getSelectedItemPosition()).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        //******************************************************************************************
    }
    public  void  goToDefaultFragment(){
        Fragment newFragment = new defaultFragment();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack
        transaction.replace(R.id.flContainerForStudent, newFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();

    }
}
