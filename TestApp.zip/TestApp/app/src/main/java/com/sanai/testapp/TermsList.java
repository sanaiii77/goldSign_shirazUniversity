package com.sanai.testapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class TermsList extends Fragment {

    RecyclerView listView;
    FragmentTransaction transaction;
    ArrayList<String> yearsList ;
    MyTermListAdapter myTermListAdapter;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_terms_info,container,false);


        //****************************data of year*********************************
        listView =view.findViewById(R.id.listOfTerms);
        yearsList = new ArrayList<>();
        yearsList.add("1390");
        yearsList.add("1391");
        yearsList.add("1392");
        yearsList.add("1393");
        yearsList.add("1394");
        yearsList.add("1395");
        yearsList.add("1396");
        yearsList.add("1397");
        yearsList.add("1398");
        yearsList.add("1399");
        yearsList.add("1400");

        //fill listview


        final MyTermListAdapter myTermListAdapter = new MyTermListAdapter(yearsList,this.getActivity());

        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 2);
        listView.setLayoutManager(mLayoutManager);

        listView.setAdapter(myTermListAdapter);

        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^




        return  view;
    }

    public  void  showSelectedItem(String year){
        Fragment newFragment = new ShowTerms();

        Bundle args = new Bundle();
        args.putString("someInt", year);
        newFragment.setArguments(args);


        transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack
        transaction.replace(R.id.flcontent, newFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();

    }

}
