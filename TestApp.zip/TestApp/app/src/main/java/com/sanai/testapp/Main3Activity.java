package com.sanai.testapp;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class Main3Activity extends AppCompatActivity {

    FrameLayout container ;
    LinearLayout selectTeacher , changePass ,result ;
    FragmentTransaction fragmentTransaction;

    // Choose time zone in which you want to interpret your Date
    Date date= new Date(); // your date
    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Iran"));
    int [] today_persion = new int[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        //**************************************************************
        container = findViewById(R.id.flContainerForTechear);
        selectTeacher = findViewById(R.id.selectStudentByTechearButton);
        changePass = findViewById(R.id.changepasswordByTechearButton);
        result = findViewById(R.id.showResultOfSelectionStudentByTeacherstButton);

        //**************************************************************
        clickButton ();

        //****************************date*********************************
        cal.setTime(date);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        today_persion = converter.gregorian_to_jalali(year,month,day);
    }

    public  void  clickButton (){
        selectTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction   =getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.flContainerForStudent,new SelectTeachersFragemnt());
                fragmentTransaction.commit();

            }
        });

        changePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction   =getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.flContainerForStudent,new ChangePassword());
                fragmentTransaction.commit();

            }
        });
        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentTransaction   =getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.flContainerForStudent,new ResultFragmnet());
                fragmentTransaction.commit();

            }
        });
    }
}
