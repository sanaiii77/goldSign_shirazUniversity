package com.sanai.testapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Calendar;


public class AddNewTerm extends Fragment {
    //1 = sal 2= mah 3=rooz
    Spinner startStudent1 , startStudent2 ,startStudent3 , finishStudent1, finishStudent2 , finishStudent3 ;
    Spinner startTeacher1 , startTeacher2 , startTeacher3 ,finishTeacher1 ,finishTeacher2 ,finishTeacher3 ;

    String[] days =new String[31];
    String[] months =new String[12];
    String[] years =new String[2];
    FragmentTransaction transaction;
    Button nextInAddNewTerm;

    int[] startTimeForStudent = new int[3]; // y 0 ,m 1 , d 2
    int[] finishTimeForStudent = new int[3];

    int[] startTimeForTeacher = new int[3];
    int[] finishTimeForTeacher = new int[3];

    Calendar cal = Calendar.getInstance();
    int [] date_shamsi = new int[3];

    LinearLayout LLtime ;
    NestedScrollView LLteacher ;
    RecyclerView listCapacityOfTechaers ;
    ArrayList<String> techearsNameList;


    //********************
    Spinner selectedAttitudeByAdmin;
    EditText thisYearByAdmin , thisEnterYearByAdmin ;
    Button nextInSelectYearsByAdmin;
    LinearLayout firstLayout ;
    String[] interest = {"هوش مصنوعی","سخت افزار","نرم افزار","فناوری اطلاعات"} ;





    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add_new_term,container,false);

        //_____________________________________________________________________________
        startStudent1 = view.findViewById(R.id.shoroeZamanEntekhabStudent1);
        startStudent2 = view.findViewById(R.id.shoroeZamanEntekhabStudent2);
        startStudent3 = view.findViewById(R.id.shoroeZamanEntekhabStuden3);
        //############################################################
        finishStudent1 = view.findViewById(R.id.payanZamanEntekhabStudent1);
        finishStudent2 = view.findViewById(R.id.payanZamanEntekhabStudent2);
        finishStudent3 = view.findViewById(R.id.payanZamanEntekhabStudent3);
        /*___________________________Teachers spinner____________________________________*/
        startTeacher1 = view.findViewById(R.id.shoroeZamanEntekhabOstad1);
        startTeacher2 = view.findViewById(R.id.shoroeZamanEntekhabOstad2);
        startTeacher3 = view.findViewById(R.id.shoroeZamanEntekhabOstad3);
        //############################################################
        finishTeacher1 = view.findViewById(R.id.payanZamanEntekhabOstad1);
        finishTeacher2 = view.findViewById(R.id.payanZamanEntekhabOstad2);
        finishTeacher3 = view.findViewById(R.id.payanZamanEntekhabOstad3);
        /*_____________________________________________________________________________*/
        nextInAddNewTerm = view.findViewById(R.id.nextInAddNewTerm);

        LLteacher = view.findViewById(R.id.LLTeacher);
        LLtime = view.findViewById(R.id.LLTime);
        listCapacityOfTechaers = view.findViewById(R.id.listCapacityTechaers);

        ///page 1********************first slect year by admin***************
        selectedAttitudeByAdmin = view.findViewById(R.id.selectAttitudeByAdmin);
        thisYearByAdmin = view.findViewById(R.id.ThisYearByAdmin);
        thisEnterYearByAdmin = view.findViewById(R.id.EnterYearByAdmin);
        nextInSelectYearsByAdmin = view.findViewById(R.id.nextInSelectYearsByAdmin);
        firstLayout = view.findViewById(R.id.firstLayout);




        //*******************************teachers list capacity**************************************
        techearsNameList = new ArrayList<>();
        techearsNameList.add("حمزه");
        techearsNameList.add("حمزه لو");
        techearsNameList.add("منصوری");
        techearsNameList.add("توحیدی");
        techearsNameList.add("دستغیبی فر");
        techearsNameList.add("کشتکاران");
        techearsNameList.add("طاهری");
        techearsNameList.add("موسوی");
        techearsNameList.add("زیارتی");
        techearsNameList.add("بوستانی");
        techearsNameList.add("خون جوش");

        LinearLayoutManager llm1= new LinearLayoutManager(this.getActivity());
        listCapacityOfTechaers.setLayoutManager(llm1);
        final MyTeacherCapacityAdapter myTeacherCapacityAdapter = new MyTeacherCapacityAdapter(techearsNameList,this.getActivity());
        listCapacityOfTechaers.setNestedScrollingEnabled(false);
        listCapacityOfTechaers.setAdapter(myTeacherCapacityAdapter);


        //*********************************************************************


        setSpinner();
        clickOnItemOfSpinners();
        clickInNext();
        return  view;
    }

    public  void setSpinner (){

        for(int i=0; i<31 ; i++){
            days[i] = i+1+"";
        }
        for(int i=0; i<12 ; i++){
            months[i] = i+1+"";
        }

        //*********************************************************************
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        date_shamsi = converter.gregorian_to_jalali(year,month,day);


        //get persian date and replace
        years[0]= date_shamsi[0] + "";
        years[1]= date_shamsi[0] +1+ "";


        //_____________________________Student start spinner___________________________________

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, years);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        startStudent1.setAdapter(adapter);
        //*********************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, months);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        startStudent2.setAdapter(adapter);
        //*********************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, days);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        startStudent3.setAdapter(adapter);

        //_____________________________Student end spinner___________________________________

        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, years);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        finishStudent1.setAdapter(adapter);
        //*********************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, months);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        finishStudent2.setAdapter(adapter);
        //*********************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, days);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        finishStudent3.setAdapter(adapter);


        /***********************************Teachers******************************************/
        //_____________________________Student start spinner___________________________________

        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, years);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        startTeacher1.setAdapter(adapter);
        //*********************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, months);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        startTeacher2.setAdapter(adapter);
        //*********************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, days);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        startTeacher3.setAdapter(adapter);

        //Teacher end spinner___________________________________

        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, years);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        finishTeacher1.setAdapter(adapter);
        //*********************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, months);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        finishTeacher2.setAdapter(adapter);
        //*********************************************************************
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, days);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        finishTeacher3.setAdapter(adapter);

        //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
        adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, interest);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        selectedAttitudeByAdmin.setAdapter(adapter);
        //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


    }

    public  void clickOnItemOfSpinners(){
        /********************************************************************************************/
        startStudent1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                startTimeForStudent[0] = Integer.parseInt( startStudent1.getItemAtPosition(startStudent1.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        }); //year
        startStudent2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                startTimeForStudent[1] = Integer.parseInt(startStudent2.getItemAtPosition(startStudent2.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        }); // month
        startStudent3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                startTimeForStudent[2] = Integer.parseInt(startStudent3.getItemAtPosition(startStudent3.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        }); // day
        //###################################################################################
        finishStudent1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                finishTimeForStudent[0] = Integer.parseInt(finishStudent1.getItemAtPosition(finishStudent1.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        }); //year
        finishStudent2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                finishTimeForStudent[1] =Integer.parseInt(finishStudent2.getItemAtPosition(finishStudent2.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        }); //month
        finishStudent3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                finishTimeForStudent[2] =Integer.parseInt( finishStudent3.getItemAtPosition(finishStudent3.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        }); //day
        /********************************************************************************************/
        startTeacher1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                startTimeForTeacher[0] = Integer.parseInt(startTeacher1.getItemAtPosition(startTeacher1.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        startTeacher2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                startTimeForTeacher[1] = Integer.parseInt(startTeacher2.getItemAtPosition(startTeacher2.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        startTeacher3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                startTimeForTeacher[2] =Integer.parseInt( startTeacher3.getItemAtPosition(startTeacher3.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        //###################################################################################
        finishStudent1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                finishTimeForTeacher[0] =Integer.parseInt( finishStudent1.getItemAtPosition(finishStudent1.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        finishStudent2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                finishTimeForTeacher[1] =Integer.parseInt( finishStudent2.getItemAtPosition(finishStudent2.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        finishStudent3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int pos, long arg3) {
                // TODO Auto-generated method stub
                finishTimeForTeacher[2] =Integer.parseInt( finishStudent3.getItemAtPosition(finishStudent3.getSelectedItemPosition()).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        /********************************************************************************************/

    }

    public  void  clickInNext(){
        nextInAddNewTerm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LLteacher.setVisibility(View.VISIBLE);
                LLtime.setVisibility(View.GONE);
            }
        });

        nextInSelectYearsByAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstLayout.setVisibility(View.GONE);
                LLtime.setVisibility(View.VISIBLE);

            }
        });

    }
    public  void  goToDefaultFargment(){
        Fragment newFragment = new defaultFragment();
         transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack
        transaction.replace(R.id.flcontent, newFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();

    }
}
