package com.sanai.testapp;

import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;


public class MyTermListAdapter extends RecyclerView.Adapter<MyTermListAdapter.MyTaskViewHolder>  {

    ArrayList<String> arrayList;
    FragmentActivity mainActivity;

    public MyTermListAdapter(ArrayList<String> arrayList, FragmentActivity mainActivity) {
        this.arrayList = arrayList;
        this.mainActivity = mainActivity;
    }

    @NonNull
    @Override
    public MyTaskViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_grid_layout, parent, false);
        MyTaskViewHolder pvh = new MyTaskViewHolder(v);
        return pvh;
    }

    @Override
    public void onBindViewHolder(final MyTaskViewHolder viewHolder, final int position) {

        String data = arrayList.get(position);
        viewHolder.name.setText(data);

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class MyTaskViewHolder extends RecyclerView.ViewHolder {
        TextView name;


        MyTaskViewHolder(View itemView) {
            super(itemView);
            name =  itemView.findViewById(R.id.yearsnameInList);


        }
    }




}
