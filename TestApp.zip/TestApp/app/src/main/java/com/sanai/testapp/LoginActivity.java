package com.sanai.testapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import jango.User;


public class LoginActivity extends AppCompatActivity {
    Button login ;
    EditText user ,password ;
    String user_str ,password_str;
    private RequestQueue requestQueue;
    public static final String LOGIN_URL =  "http://192.168.1.105:8000/api/users/";
    ArrayList<User> userList = new ArrayList<>()  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = findViewById(R.id.login);
        user = findViewById(R.id.user);
        password = findViewById(R.id.password);

        click ();


    }
    public  void click (){


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //getUsersByIon(getApplicationContext());
                user_str = user.getText().toString();
                password_str = password.getText().toString();
                String whoIsUser = checkUser (user_str,password_str);

                if (whoIsUser.matches("student")){
                    Intent mainIntent = new Intent(LoginActivity.this,Main2Activity.class);
                    LoginActivity.this.startActivity(mainIntent);
                    LoginActivity.this.finish();

                }else if(whoIsUser.matches("admin")){

                    Intent mainIntent = new Intent(LoginActivity.this,MainActivity.class);
                    LoginActivity.this.startActivity(mainIntent);
                    LoginActivity.this.finish();


                }
                else if(whoIsUser.matches("techear")){
                    Intent mainIntent = new Intent(LoginActivity.this,Main3Activity.class);
                    LoginActivity.this.startActivity(mainIntent);
                    LoginActivity.this.finish();

                }
                else{
                    user.setText("");
                    password.setText("");
                    Toast.makeText(LoginActivity.this, "رمز عبور اشتباه است،دوباره تلاش کنید.", Toast.LENGTH_LONG).show();

                }



            }
        });
    }

    public  String checkUser(String user,String pass){
        //check user information in backend and return result


        return  "admin";

    }

    public void getUsersByIon (final Context context){
        Ion.with(context)
                .load("http://example.com/thing.json")
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        // do stuff with the result or error
                        Toast.makeText(context,result+"",Toast.LENGTH_LONG).show();
                    }
                });
    }


    private void jsonParse() {


        String URL =  "http://192.168.1.105:8000/api/user/3/";
        StringRequest stringRequest = new StringRequest(URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                GsonBuilder gsonBuilder = new GsonBuilder();
                Gson gson = gsonBuilder.create();
                Toast.makeText(LoginActivity.this, "hey there"+response, Toast.LENGTH_LONG).show();
                //User[] userArray = gson.fromJson(response,User[].class);
                //Toast.makeText(LoginActivity.this, ""+userArray, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("MainActivity.class", "onErrorResponse: " + error.getMessage());
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void postData(final String username , final String password) {

        final ProgressDialog loading = new ProgressDialog(LoginActivity.this);
        loading.setMessage("Please Wait...");
        loading.setCanceledOnTouchOutside(false);
        loading.show();

        try {
            String URL =  "http://192.168.1.105:8000/api/user/3/";
            JSONObject jsonBody = new JSONObject();

            jsonBody.put("username", "sana");
            jsonBody.put("password", "testingchangepass");
            jsonBody.put("pk", 3);



            JsonObjectRequest jsonOblect = new JsonObjectRequest(Request.Method.PATCH, URL, jsonBody, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    Toast.makeText(getApplicationContext(), "Response:  " + response.toString(), Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    onBackPressed();

                }
            }) {

            };

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(jsonOblect);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        // Toast.makeText(getApplicationContext(), "done", Toast.LENGTH_LONG).show();

    }

    public void changemajor() {

        final ProgressDialog loading = new ProgressDialog(LoginActivity.this);
        loading.setMessage("Please Wait...");
        loading.setCanceledOnTouchOutside(false);
        loading.show();

        try {
            String URL =  "http://192.168.1.105:8000/api/user/list/";
            JSONObject jsonBody = new JSONObject();

            jsonBody.put("title", "test");
            jsonBody.put("pk", 1);


            JsonObjectRequest jsonOblect = new JsonObjectRequest(Request.Method.POST, URL, jsonBody, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    Toast.makeText(getApplicationContext(), "Response:  " + response.toString(), Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    onBackPressed();

                }
            }) {

            };

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(jsonOblect);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        // Toast.makeText(getApplicationContext(), "done", Toast.LENGTH_LONG).show();

    }



    public interface VolleyCallback{
        void onSuccess(JSONArray jsonArray);
    }


    private void fetch(RequestQueue requestQueue , final VolleyCallback callback) {
        JsonArrayRequest request = new JsonArrayRequest("http://192.168.1.105:8000/api/user/list/",
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray jsonArray) {
                        callback.onSuccess(jsonArray);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        Toast.makeText(LoginActivity.this, "Unable to fetch data: " + volleyError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


        requestQueue.add(request);
    }



}









