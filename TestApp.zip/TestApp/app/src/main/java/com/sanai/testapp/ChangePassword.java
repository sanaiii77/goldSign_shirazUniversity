package com.sanai.testapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class ChangePassword extends Fragment {

    EditText password ,reEnterPassword;
    Button cancele , save ;

    String passwordText ,repasswordText ;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_change_password,container,false);
        password = view.findViewById(R.id.password);
        reEnterPassword = view.findViewById(R.id.repassword);
        cancele = view.findViewById(R.id.cancelChangePassword);
        save =  view.findViewById(R.id.changePassword);
        //___________________________________________________________________________________\\
        change();
        canceleChangePass();



        return  view;
    }

    public void change(){

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                passwordText = password.getText().toString();
                repasswordText = reEnterPassword.getText().toString();
                if(passwordText.matches("") || repasswordText.matches("")){
                    Toast.makeText(getActivity(), "empty", Toast.LENGTH_SHORT).show();

                }else {
                    if (passwordText.equals(repasswordText)) {
                        //backend do change pass
                        Toast.makeText(getActivity(), "password changed", Toast.LENGTH_SHORT).show();


                    } else {

                        password.setText("");
                        reEnterPassword.setText("");
                        Toast.makeText(getActivity(), "doenst match", Toast.LENGTH_SHORT).show();
                    }

                    goToDefaultFargment();
                }

            }
        });


    }
    public  void canceleChangePass (){

        cancele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                goToDefaultFargment();

            }
        });

    }

    public  void  goToDefaultFargment(){
        Fragment newFragment = new defaultFragment();
        FragmentTransaction transaction = getFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack
        transaction.replace(R.id.flcontent, newFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();

    }
}
